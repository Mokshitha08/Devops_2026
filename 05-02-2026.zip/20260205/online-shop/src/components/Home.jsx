function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome to the Online Shop!</p>
    </div>
  );
}

export default Home;